<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';

function getDistance($lat1, $lon1, $lat2, $lon2) {
    if (($lat1 == $lat2) && ($lon1 == $lon2)) {
        return 0;
    }
    
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    
    $miles = $dist * 60 * 1.1515;
    $meters = $miles * 1609.344; // Convert miles to meters
    return $meters;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $sessionId = trim($input['session_id'] ?? '');
    
    // Normalize Student Name to prevent duplicates from typos/spaces
    $rawName = trim($input['student_name'] ?? '');
    $studentName = ucwords(strtolower(preg_replace('/\s+/', ' ', $rawName)));

    $lat = isset($input['lat']) ? floatval($input['lat']) : null;
    $lng = isset($input['lng']) ? floatval($input['lng']) : null;

    if (empty($sessionId) || empty($studentName) || $lat === null || $lng === null) {
        echo json_encode(["success" => false, "error" => "Missing required parameters"]);
        exit;
    }

    try {
        // Find the session
        $stmt = $pdo->prepare("SELECT * FROM sessions WHERE id = ?");
        $stmt->execute([$sessionId]);
        $session = $stmt->fetch();

        if (!$session) {
            echo json_encode(["success" => false, "error" => "Session not found. Please scan a valid QR code."]);
            exit;
        }

        // Check if session is active
        if ($session['status'] !== 'active') {
            echo json_encode(["success" => false, "error" => "This session is no longer active."]);
            exit;
        }

        // Calculate distance
        $distance = getDistance((float)$session['lat'], (float)$session['lng'], $lat, $lng);
        $radius = (float)$session['radius'];

        if ($distance > $radius) {
            echo json_encode([
                "success" => false, 
                "error" => "Geolocation verification failed. You are ". round($distance) ." meters away, but must be within ". round($radius) ." meters of the classroom.",
                "distance" => round($distance),
                "allowed_radius" => round($radius)
            ]);
            exit;
        }

        // 50 STUDENT LIMIT CHECK
        $stmtCapacity = $pdo->prepare("SELECT COUNT(*) as current_count FROM attendance WHERE session_id = ?");
        $stmtCapacity->execute([$sessionId]);
        $sessionStats = $stmtCapacity->fetch();

        if ($sessionStats['current_count'] >= 50) {
            echo json_encode([
                "success" => false, 
                "error" => "Session is full. The maximum limit of 50 attendees has been reached."
            ]);
            exit;
        }

        // Check if student already submitted attendance
        $stmt = $pdo->prepare("SELECT id FROM attendance WHERE session_id = ? AND student_name = ?");
        $stmt->execute([$sessionId, $studentName]);
        if ($stmt->fetch()) {
            echo json_encode(["success" => false, "error" => "Attendance already recorded for this session"]);
            exit;
        }

        $subject = $session['subject'];
        $section = $session['section'];
        $currentDate = date('Y-m-d');
        $currentTimestamp = date('Y-m-d H:i:s');

        // Submit attendance
        $stmt = $pdo->prepare("INSERT INTO attendance (session_id, student_name, subject, section, distance, status, date, timestamp) VALUES (?, ?, ?, ?, ?, 'present', ?, ?)");
        $stmt->execute([$sessionId, $studentName, $subject, $section, $distance, $currentDate, $currentTimestamp]);

        echo json_encode([
            "success" => true,
            "message" => "Attendance recorded successfully for {$subject} ({$section})!",
            "subject" => $subject,
            "section" => $section,
            "distance" => round($distance) . "m"
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "error" => "Database error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "error" => "Invalid method"]);
}
?>