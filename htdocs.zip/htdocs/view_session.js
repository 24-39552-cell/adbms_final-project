document.addEventListener('DOMContentLoaded', () => {
    // Get the session ID from the URL (e.g., view_session.html?session=12345)
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session');

    if (!sessionId) {
        document.getElementById('sessionSummary').innerHTML = `<p style="color: var(--error);">No session ID provided. Please go back to Analytics and select a session.</p>`;
        return;
    }

    // Fetch the report data
    fetch(`api/get_data.php?action=report&session_id=${sessionId}`)
        .then(response => response.json())
        .then(res => {
            if (res.success && res.session_info) {
                const info = res.session_info;
                const attendees = res.data;

                // 1. Build the Summary Box
                const dateObj = new Date(info.created_at.replace(' ', 'T'));
                const formattedDate = dateObj.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

                document.getElementById('sessionSummary').innerHTML = `
                    <div class="summary-block">
                        <h3>${escapeHtml(info.subject)}</h3>
                        <p><strong>Section:</strong> ${escapeHtml(info.section)}</p>
                        <p><strong>Professor:</strong> ${escapeHtml(info.professor_name)}</p>
                    </div>
                    <div class="summary-block" style="text-align: right;">
                        <p><strong>Date:</strong> ${formattedDate}</p>
                        <p><strong>Status:</strong> <span class="badge ${info.status === 'completed' ? 'badge-error' : 'badge-success'}">${info.status.toUpperCase()}</span></p>
                        <p><strong>Total Attendees:</strong> <span style="font-size: 1.2rem; color: var(--success); font-weight: bold;">${info.total_attendees || 0}</span></p>
                    </div>
                `;

                // 2. Enable the Download Button
                const downloadBtn = document.getElementById('downloadExcelBtn');
                downloadBtn.disabled = false;
                downloadBtn.addEventListener('click', () => {
                    window.location.href = `api/export_excel.php?session_id=${sessionId}`;
                });

                // 3. Populate the Roster Table
                const tbody = document.querySelector('#archiveTable tbody');
                
                if (attendees.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="4" class="text-center">No students attended this session.</td></tr>';
                } else {
                    tbody.innerHTML = '';
                    attendees.forEach(row => {
                        const tr = document.createElement('tr');
                        
                        // Format the timestamp
                        const timeObj = new Date(row.timestamp.replace(' ', 'T'));
                        const timeStr = timeObj.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
                        
                        tr.innerHTML = `
                            <td><strong>${escapeHtml(row.student_name)}</strong></td>
                            <td>${timeStr}</td>
                            <td><span class="badge badge-success">Present</span></td>
                            <td>${Math.round(row.distance)}m</td>
                        `;
                        tbody.appendChild(tr);
                    });
                }
            } else {
                document.getElementById('sessionSummary').innerHTML = `<p style="color: var(--error);">Error loading session: ${res.error || 'Session not found'}</p>`;
            }
        })
        .catch(err => {
            console.error(err);
            document.getElementById('sessionSummary').innerHTML = `<p style="color: var(--error);">Network error while loading data.</p>`;
        });
});

// Helper function to prevent XSS
function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return String(unsafe)
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}