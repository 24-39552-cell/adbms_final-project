let activeSessionId = null;
let pollInterval = null;

// Populate initial location
document.getElementById('getLocationBtn').addEventListener('click', () => {
    const btn = document.getElementById('getLocationBtn');
    if (!navigator.geolocation) {
        alert('Geolocation is not supported by your browser');
        return;
    }
    
    btn.innerText = "Locating...";
    btn.disabled = true;
    
    navigator.geolocation.getCurrentPosition(
        (position) => {
            document.getElementById('lat').value = position.coords.latitude.toFixed(7);
            document.getElementById('lng').value = position.coords.longitude.toFixed(7);
            btn.innerText = "📍 Get My Location";
            btn.disabled = false;
        },
        (error) => {
            let errorMsg = 'Unable to retrieve your location. ';
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMsg += 'Location permission denied.';
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMsg += 'Location information unavailable.';
                    break;
                case error.TIMEOUT:
                    errorMsg += 'Location request timed out.';
                    break;
                default:
                    errorMsg += error.message;
            }
            alert(errorMsg);
            btn.innerText = "📍 Get My Location";
            btn.disabled = false;
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }
    );
});

// Create Session
document.getElementById('createSessionBtn').addEventListener('click', () => {
    const subject = document.getElementById('subject').value.trim();
    const section = document.getElementById('section').value.trim();
    const professor = document.getElementById('professor').value.trim();
    const lat = document.getElementById('lat').value;
    const lng = document.getElementById('lng').value;
    const radius = document.getElementById('radius').value;
    
    if(!subject || !section || !professor || !lat || !lng || !radius) {
        alert("Please fill out all fields (Subject, Section, Professor Name, Latitude, Longitude, and Allowed Radius).");
        return;
    }
    
    // Validate coordinates
    if(parseFloat(lat) < -90 || parseFloat(lat) > 90 || parseFloat(lng) < -180 || parseFloat(lng) > 180) {
        alert("Invalid coordinates. Latitude must be between -90 and 90, longitude between -180 and 180.");
        return;
    }
    
    const btn = document.getElementById('createSessionBtn');
    btn.disabled = true;
    btn.innerText = "Generating...";
    
    fetch('api/create_session.php', {
        method: 'POST',
        body: JSON.stringify({ 
            subject, 
            section, 
            professor, 
            lat: parseFloat(lat), 
            lng: parseFloat(lng), 
            radius: parseInt(radius) || 50 
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(r => r.json())
    .then(data => {
        btn.disabled = false;
        btn.innerText = "Generate Session QR";
        
        if(data.success) {
            activeSessionId = data.session_id;
            
            // Clear previous QR
            document.getElementById('qrcode').innerHTML = "";
            document.getElementById('qrcode').style.display = "block";
            
            // Generate QR Code with JUST the session ID (no JSON wrapper)
            new QRCode(document.getElementById("qrcode"), {
                text: activeSessionId,
                width: 250,
                height: 250,
                colorDark : "#2c5364",
                colorLight : "#ffffff",
                correctLevel : QRCode.CorrectLevel.H
            });
            
            // Show the subject and section under the QR code
            document.getElementById('sessionInfo').innerHTML = `
                <strong>${escapeHtml(subject)}</strong> (${escapeHtml(section)})<br>
                Professor: ${escapeHtml(professor)}<br>
                Session ID: <span style="font-size: 0.85em; word-break: break-all;">${activeSessionId}</span>
            `;
            
            // Start Polling Report
            if(pollInterval) clearInterval(pollInterval);
            fetchReport(); // initial fetch
            pollInterval = setInterval(fetchReport, 3000); // update UI every 3 sec
            
            // Enable Download Button
            document.getElementById('downloadReportBtn').disabled = false;
            
            // Show success notification
            showNotification('Session created successfully! QR code generated.', 'success');
        } else {
            showNotification("Error: " + (data.error || 'Unknown error'), 'error');
        }
    })
    .catch(err => {
        btn.disabled = false;
        btn.innerText = "Generate Session QR";
        showNotification("Network error. Please check your connection.", 'error');
        console.error('Fetch error:', err);
    });
});

function fetchReport() {
    if(!activeSessionId) return;
    
    fetch(`api/get_data.php?action=report&session_id=${activeSessionId}`)
    .then(r => r.json())
    .then(res => {
        const tbody = document.querySelector('#reportTable tbody');
        
        if(res.success) {
            const data = res.data;
            document.getElementById('totalAttended').innerText = data.length;
            
            if(data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="3" class="text-center">No attendees yet.</td></tr>';
            } else {
                tbody.innerHTML = '';
                
                data.forEach(row => {
                    const statusClass = row.status === 'present' ? 'badge-success' : 'badge-error';
                    const tr = document.createElement('tr');
                    
                    // Parse and format the timestamp properly
                    let formattedDate = 'Unknown';
                    let formattedTime = '';
                    
                    try {
                        if (row.timestamp) {
                            const parts = row.timestamp.split(' ');
                            if (parts.length === 2) {
                                const datePart = parts[0];
                                const timePart = parts[1];
                                
                                // Create date object
                                const dateObj = new Date(datePart + 'T' + timePart);
                                
                                if (!isNaN(dateObj.getTime())) {
                                    // Format date as "Jan 15, 2024"
                                    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                                                   'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                                    formattedDate = months[dateObj.getMonth()] + ' ' + 
                                                   dateObj.getDate() + ', ' + 
                                                   dateObj.getFullYear();
                                    
                                    // Format time as "2:30 PM"
                                    let hours = dateObj.getHours();
                                    const minutes = dateObj.getMinutes().toString().padStart(2, '0');
                                    const ampm = hours >= 12 ? 'PM' : 'AM';
                                    hours = hours % 12;
                                    hours = hours ? hours : 12;
                                    formattedTime = hours + ':' + minutes + ' ' + ampm;
                                }
                            }
                        }
                    } catch(e) {
                        console.error('Date parsing error:', e);
                        formattedDate = row.timestamp || 'Unknown';
                    }
                    
                    const displayDateTime = formattedTime ? 
                        formattedDate + ' ' + formattedTime : 
                        formattedDate;
                    
                    tr.innerHTML = `
                        <td>${escapeHtml(row.student_name || 'Unknown')}</td>
                        <td>${displayDateTime}</td>
                        <td><span class="badge ${statusClass}">${row.status === 'present' ? 'Present' : 'Absent'} (${Math.round(row.distance || 0)}m)</span></td>
                    `;
                    tbody.appendChild(tr);
                });
            }
        } else {
            console.error('Report fetch error:', res.error);
        }
    })
    .catch(err => {
        console.error('Report fetch failed:', err);
    });
}

function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return String(unsafe)
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        border-radius: 10px;
        color: #fff;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease, fadeOut 0.3s ease 2.7s forwards;
        max-width: 400px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    `;
    
    switch(type) {
        case 'success':
            notification.style.background = 'linear-gradient(135deg, #00e676, #00c853)';
            break;
        case 'error':
            notification.style.background = 'linear-gradient(135deg, #ff5252, #ff1744)';
            break;
        default:
            notification.style.background = 'linear-gradient(135deg, #00f2fe, #4facfe)';
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 3000);
}

// Download Report Button
document.getElementById('downloadReportBtn').addEventListener('click', () => {
    if(!activeSessionId) {
        showNotification('No active session selected.', 'error');
        return;
    }
    window.location.href = `api/export_excel.php?session_id=${activeSessionId}`;
});

// Add notification animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
`;
document.head.appendChild(style);