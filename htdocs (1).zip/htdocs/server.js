const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./database');
const qrcode = require('qrcode');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public')); // Serve the frontend files

// Calculate distance between two coordinates in meters
function getDistance(lat1, lon1, lat2, lon2) {
    const R = 6371e3; // Earth radius in meters
    const p1 = lat1 * Math.PI / 180;
    const p2 = lat2 * Math.PI / 180;
    const dp = (lat2 - lat1) * Math.PI / 180;
    const dl = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(dp / 2) * Math.sin(dp / 2) +
        Math.cos(p1) * Math.cos(p2) *
        Math.sin(dl / 2) * Math.sin(dl / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // Distance in meters
}

// API: Create a new attendance session
app.post('/api/sessions', async (req, res) => {
    const { lat, lng, radius } = req.body;
    
    // Generate a secure unique ID for the session
    const sessionId = crypto.randomBytes(16).toString('hex');
    
    db.run(
        `INSERT INTO Sessions (id, lat, lng, radius, status) VALUES (?, ?, ?, ?, 'active')`,
        [sessionId, lat, lng, radius || 50],
        async function (err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            
            // Generate QR code base64 containing the session ID
            try {
                // In production, this might be a full URL to the scan page
                // such as: http://your-domain.com/scan.html?session=sessionId
                // For this project, we send just the session ID or a relative URL object
                const qrPayload = JSON.stringify({ session_id: sessionId });
                const qrImage = await qrcode.toDataURL(qrPayload);
                
                res.status(201).json({
                    message: 'Session created successfully',
                    session_id: sessionId,
                    qr_image: qrImage
                });
            } catch (qrErr) {
                res.status(500).json({ error: 'Failed to generate QR code' });
            }
        }
    );
});

// API: Submit attendance
app.post('/api/attend', (req, res) => {
    const { session_id, student_name, lat, lng } = req.body;

    if (!session_id || !student_name || !lat || !lng) {
        return res.status(400).json({ error: 'Missing required parameters' });
    }

    // Check if session exists and is active
    db.get(`SELECT * FROM Sessions WHERE id = ? AND status = 'active'`, [session_id], (err, session) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!session) return res.status(404).json({ error: 'Invalid or expired session' });

        // Calculate distance from session location
        const distance = getDistance(session.lat, session.lng, lat, lng);
        
        // Determine status (present if within radius, else rejected/out_of_range)
        if (distance > session.radius) {
            return res.status(403).json({ 
                error: 'Geolocation verification failed. You are too far from the classroom.',
                distance: Math.round(distance),
                allowed_radius: session.radius
            });
        }

        // Check if student already signed in for this session
        db.get(`SELECT * FROM Attendance WHERE session_id = ? AND student_name = ?`, [session_id, student_name], (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            if (row) return res.status(400).json({ error: 'Attendance already recorded for this session' });

            // Record attendance
            db.run(
                `INSERT INTO Attendance (session_id, student_name, distance, status) VALUES (?, ?, ?, 'present')`,
                [session_id, student_name, distance],
                function (err) {
                    if (err) return res.status(500).json({ error: err.message });
                    res.status(201).json({ message: 'Attendance recorded successfully!' });
                }
            );
        });
    });
});

// API: End a session
app.post('/api/sessions/:id/end', (req, res) => {
    const { id } = req.params;
    db.run(`UPDATE Sessions SET status = 'completed' WHERE id = ?`, [id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Session ended successfully' });
    });
});

// API: Get attendance report for a session
app.get('/api/sessions/:id/report', (req, res) => {
    const { id } = req.params;
    db.all(`SELECT student_name, timestamp, distance, status FROM Attendance WHERE session_id = ? ORDER BY timestamp DESC`, [id], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// API: Get all active sessions
app.get('/api/sessions', (req, res) => {
    db.all(`SELECT * FROM Sessions ORDER BY created_at DESC`, [], (err, rows) => {
         if (err) return res.status(500).json({ error: err.message });
         res.json(rows);
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
