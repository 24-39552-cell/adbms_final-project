<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';

$action = $_GET['action'] ?? '';

try {
    switch($action) {
        // UNION: Combine attendance from multiple sessions
        case 'combined_attendance':
            $session1 = $_GET['session1'] ?? '';
            $session2 = $_GET['session2'] ?? '';
            
            if (empty($session1) || empty($session2)) {
                echo json_encode(["success" => false, "error" => "Two session IDs required"]);
                exit;
            }
            
            $stmt = $pdo->prepare("
                SELECT student_name, subject, section, timestamp, 'Session 1' as source
                FROM attendance WHERE session_id = ?
                UNION
                SELECT student_name, subject, section, timestamp, 'Session 2' as source
                FROM attendance WHERE session_id = ?
                ORDER BY student_name, timestamp
            ");
            $stmt->execute([$session1, $session2]);
            echo json_encode(["success" => true, "data" => $stmt->fetchAll()]);
            break;
            
        // INTERSECT concept: Students with perfect attendance
        case 'perfect_attendance':
            $subject = $_GET['subject'] ?? '';
            $section = $_GET['section'] ?? '';
            
            if (empty($subject) || empty($section)) {
                echo json_encode(["success" => false, "error" => "Subject and section required"]);
                exit;
            }
            
            $stmt = $pdo->prepare("
                SELECT 
                    a.student_name,
                    COUNT(DISTINCT a.session_id) as sessions_attended,
                    (SELECT COUNT(*) FROM sessions WHERE subject = ? AND section = ?) as total_sessions,
                    GROUP_CONCAT(DISTINCT DATE(a.timestamp) ORDER BY DATE(a.timestamp) SEPARATOR ', ') as attendance_dates
                FROM attendance a
                WHERE a.subject = ? AND a.section = ? AND a.status = 'present'
                GROUP BY a.student_name
                HAVING COUNT(DISTINCT a.session_id) = (
                    SELECT COUNT(*) FROM sessions WHERE subject = ? AND section = ?
                )
            ");
            $stmt->execute([$subject, $section, $subject, $section, $subject, $section]);
            echo json_encode([
                "success" => true, 
                "perfect_attenders" => $stmt->fetchAll(),
                "message" => "Students who attended ALL sessions"
            ]);
            break;
            
        // EXCEPT concept using NOT IN: Students who missed a specific session
        case 'students_not_attended':
            $sessionId = $_GET['session_id'] ?? '';
            
            if (empty($sessionId)) {
                echo json_encode(["success" => false, "error" => "Session ID required"]);
                exit;
            }
            
            // Get session info first
            $stmt = $pdo->prepare("SELECT * FROM sessions WHERE id = ?");
            $stmt->execute([$sessionId]);
            $session = $stmt->fetch();
            
            if (!$session) {
                echo json_encode(["success" => false, "error" => "Session not found"]);
                exit;
            }
            
            // EXCEPT equivalent using NOT IN
            $stmt = $pdo->prepare("
                SELECT 
                    r.student_name,
                    r.subject,
                    r.section
                FROM roster r
                WHERE r.subject = ? 
                    AND r.section = ?
                    AND r.student_name NOT IN (
                        SELECT a.student_name 
                        FROM attendance a
                        WHERE a.session_id = ?
                    )
                ORDER BY r.student_name
            ");
            $stmt->execute([$session['subject'], $session['section'], $sessionId]);
            echo json_encode([
                "success" => true, 
                "absent_students" => $stmt->fetchAll(),
                "session_info" => $session
            ]);
            break;
            
        // Advanced Analytics with multiple JOINs and aggregations
        case 'analytics':
            $stmt = $pdo->query("
                SELECT 
                    s.subject,
                    s.section,
                    COUNT(DISTINCT s.id) as total_sessions,
                    COUNT(DISTINCT a.student_name) as unique_students,
                    COUNT(a.id) as total_attendance_records,
                    ROUND(AVG(a.distance), 2) as avg_distance,
                    MAX(a.distance) as max_distance,
                    MIN(a.distance) as min_distance,
                    ROUND(AVG(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) * 100, 2) as attendance_rate,
                    SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_count,
                    SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) as absent_count
                FROM sessions s
                LEFT JOIN attendance a ON s.id = a.session_id
                WHERE s.status = 'completed'
                GROUP BY s.subject, s.section
                ORDER BY unique_students DESC
            ");
            echo json_encode(["success" => true, "analytics" => $stmt->fetchAll()]);
            break;
            
        // Student ranking by attendance (Subquery in SELECT)
        case 'student_ranking':
            $limit = intval($_GET['limit'] ?? 10);
            
            $stmt = $pdo->prepare("
                SELECT 
                    student_name,
                    COUNT(*) as total_attendances,
                    COUNT(DISTINCT session_id) as unique_sessions,
                    ROUND(AVG(distance), 2) as avg_distance,
                    (
                        SELECT COUNT(DISTINCT s2.id) 
                        FROM sessions s2 
                        WHERE s2.status = 'completed'
                    ) as total_completed_sessions
                FROM attendance
                WHERE status = 'present'
                GROUP BY student_name
                ORDER BY total_attendances DESC
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            echo json_encode([
                "success" => true, 
                "top_students" => $stmt->fetchAll(),
                "message" => "Top $limit students by attendance"
            ]);
            break;
            
        // Session comparison report
        case 'session_comparison':
            $subject = $_GET['subject'] ?? '';
            
            if (empty($subject)) {
                echo json_encode(["success" => false, "error" => "Subject required"]);
                exit;
            }
            
            $stmt = $pdo->prepare("
                SELECT 
                    s.id as session_id,
                    s.section,
                    s.professor_name,
                    DATE(s.created_at) as session_date,
                    COUNT(a.id) as attendance_count,
                    ROUND(AVG(a.distance), 2) as avg_distance
                FROM sessions s
                LEFT JOIN attendance a ON s.id = a.session_id
                WHERE s.subject = ?
                GROUP BY s.id
                ORDER BY s.created_at DESC
            ");
            $stmt->execute([$subject]);
            echo json_encode(["success" => true, "data" => $stmt->fetchAll()]);
            break;
            
        default:
            echo json_encode(["success" => false, "error" => "Invalid action"]);
    }
} catch (PDOException $e) {
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>