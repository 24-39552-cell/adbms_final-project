<?php
require_once 'db.php';

if (!isset($_GET['session_id'])) {
    die("Session ID is required.");
}
$sessionId = $_GET['session_id'];

// Get session info with attendance statistics
$stmt = $pdo->prepare("
    SELECT 
        s.*,
        COUNT(a.id) as total_attendees,
        SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_count
    FROM sessions s
    LEFT JOIN attendance a ON s.id = a.session_id
    WHERE s.id = ?
    GROUP BY s.id
");
$stmt->execute([$sessionId]);
$session = $stmt->fetch();

if (!$session) {
    die("Session not found.");
}

$filename = "attendance_" . preg_replace('/[^a-zA-Z0-9_]/', '_', $session['subject']) . "_" . $session['section'] . "_" . date('Y-m-d') . ".xls";

header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

echo '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';
echo '<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
echo '<h2>QuickAttend - Attendance Report</h2>';
echo '<p><strong>Subject:</strong> ' . htmlspecialchars($session['subject']) . '</p>';
echo '<p><strong>Section:</strong> ' . htmlspecialchars($session['section']) . '</p>';
echo '<p><strong>Professor:</strong> ' . htmlspecialchars($session['professor_name']) . '</p>';
echo '<p><strong>Date:</strong> ' . htmlspecialchars(date('F j, Y', strtotime($session['created_at']))) . '</p>';
echo '<p><strong>Total Attendees:</strong> ' . $session['total_attendees'] . ' | <strong>Present:</strong> ' . $session['present_count'] . '</p>';
echo '<br>';

echo '<table border="1">';
echo '<tr style="background-color: #2c5364; color: #ffffff;">';
echo '<th>#</th>';
echo '<th>Student Name</th>';
echo '<th>Subject</th>';
echo '<th>Section</th>';
echo '<th>Professor Name</th>';
echo '<th>Date</th>';
echo '<th>Time</th>';
echo '<th>Status</th>';
echo '<th>Distance (m)</th>';
echo '</tr>';

// Fetch attendees with INNER JOIN
$stmt = $pdo->prepare("
    SELECT 
        a.student_name, 
        a.subject, 
        a.section, 
        a.date, 
        a.timestamp, 
        a.status, 
        a.distance,
        s.professor_name
    FROM attendance a
    INNER JOIN sessions s ON a.session_id = s.id
    WHERE a.session_id = ? 
    ORDER BY a.timestamp DESC
");
$stmt->execute([$sessionId]);
$attendees = $stmt->fetchAll();

$counter = 1;
foreach ($attendees as $row) {
    $time = date("h:i A", strtotime($row['timestamp']));
    $dateFormatted = date("M d, Y", strtotime($row['date']));
    $status = $row['status'] == 'present' ? '✅ Present' : '❌ Absent';
    $distance = round($row['distance']) . 'm';
    
    $bgColor = $row['status'] == 'present' ? '#ffffff' : '#fff5f5';
    
    echo '<tr style="background-color: ' . $bgColor . ';">';
    echo '<td>' . $counter++ . '</td>';
    echo '<td>' . htmlspecialchars($row['student_name']) . '</td>';
    echo '<td>' . htmlspecialchars($row['subject'] ?? $session['subject']) . '</td>';
    echo '<td>' . htmlspecialchars($row['section'] ?? $session['section']) . '</td>';
    echo '<td>' . htmlspecialchars($row['professor_name'] ?? $session['professor_name']) . '</td>';
    echo '<td>' . $dateFormatted . '</td>';
    echo '<td>' . $time . '</td>';
    echo '<td>' . $status . '</td>';
    echo '<td>' . $distance . '</td>';
    echo '</tr>';
}

echo '<tr style="background-color: #f0f0f0; font-weight: bold;">';
echo '<td colspan="8" style="text-align: right;">Total Students Present:</td>';
echo '<td>' . $session['present_count'] . '</td>';
echo '</tr>';

echo '<tr style="background-color: #f9f9f9;">';
echo '<td colspan="9" style="text-align: center; font-style: italic;">';
echo 'Report generated on ' . date('F j, Y \a\t h:i A') . ' by QuickAttend System';
echo '</td>';
echo '</tr>';

echo '</table></body></html>';
?>