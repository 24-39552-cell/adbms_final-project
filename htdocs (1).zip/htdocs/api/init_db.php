<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickAttend - Database Setup</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2.5rem;
            max-width: 700px;
            width: 100%;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }
        h1 {
            margin-bottom: 0.5rem;
            font-size: 2rem;
            background: linear-gradient(to right, #00f2fe, #4facfe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .subtitle {
            color: rgba(255,255,255,0.6);
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }
        .message {
            padding: 1rem;
            margin: 0.7rem 0;
            border-radius: 10px;
            background: rgba(0, 0, 0, 0.2);
            border-left: 4px solid #00f2fe;
            font-size: 0.95rem;
        }
        .message.error {
            border-left-color: #ff5252;
            background: rgba(255, 82, 82, 0.1);
        }
        .message.success {
            border-left-color: #00e676;
            background: rgba(0, 230, 118, 0.1);
        }
        .btn {
            display: inline-block;
            padding: 0.8rem 1.5rem;
            margin-top: 1.5rem;
            margin-right: 0.5rem;
            background: linear-gradient(135deg, #00f2fe, #4facfe);
            color: #fff;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
            transition: transform 0.3s, box-shadow 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 242, 254, 0.4);
        }
        ul {
            margin-top: 1rem;
            padding-left: 1.5rem;
            color: rgba(255,255,255,0.7);
        }
        li {
            margin: 0.5rem 0;
        }
        code {
            background: rgba(0,0,0,0.3);
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 QuickAttend Database Setup</h1>
        <p class="subtitle">Initializing database tables for the attendance system</p>
        <?php
        $host = '127.0.0.1';
        $user = 'root';
        $pass = '';

        try {
            // Connect to MySQL server first without a database
            $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Create Database
            $pdo->exec("CREATE DATABASE IF NOT EXISTS quickattend");
            echo '<div class="message success">✅ Database <code>quickattend</code> created successfully.</div>';

            // Connect to specific database
            $pdo->exec("USE quickattend");
            
            // Set timezone
            $pdo->exec("SET time_zone = '+08:00'");

            // Create Sessions table with all required columns
            $query = "CREATE TABLE IF NOT EXISTS sessions (
                id VARCHAR(64) PRIMARY KEY,
                subject VARCHAR(255) NOT NULL,
                section VARCHAR(100) NOT NULL,
                professor_name VARCHAR(255) NOT NULL,
                lat DECIMAL(10, 8) NOT NULL,
                lng DECIMAL(11, 8) NOT NULL,
                radius FLOAT DEFAULT 50,
                status VARCHAR(20) DEFAULT 'active',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_status (status),
                INDEX idx_subject_section (subject, section),
                INDEX idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($query);
            echo '<div class="message success">✅ <code>sessions</code> table ready with indexes.</div>';

            // Create Attendance table
            $query = "CREATE TABLE IF NOT EXISTS attendance (
                id INT AUTO_INCREMENT PRIMARY KEY,
                session_id VARCHAR(64) NOT NULL,
                student_name VARCHAR(100) NOT NULL,
                subject VARCHAR(255),
                section VARCHAR(100),
                date DATE DEFAULT (CURRENT_DATE),
                distance FLOAT DEFAULT 0,
                status VARCHAR(20) DEFAULT 'present',
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_session_id (session_id),
                INDEX idx_student_name (student_name),
                INDEX idx_date (date),
                INDEX idx_status (status),
                INDEX idx_subject_section (subject, section),
                FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($query);
            echo '<div class="message success">✅ <code>attendance</code> table ready with indexes.</div>';

            // Create Roster table for class lists (supporting advanced features)
            $query = "CREATE TABLE IF NOT EXISTS roster (
                id INT AUTO_INCREMENT PRIMARY KEY,
                student_id VARCHAR(50),
                student_name VARCHAR(100) NOT NULL,
                subject VARCHAR(255) NOT NULL,
                section VARCHAR(100) NOT NULL,
                UNIQUE KEY unique_enrollment (student_name, subject, section),
                INDEX idx_subject_section (subject, section),
                INDEX idx_student_name (student_name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($query);
            echo '<div class="message success">✅ <code>roster</code> table ready for class lists.</div>';

            // Insert sample roster data if empty
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM roster");
            $count = $stmt->fetch()['count'];
            
            if ($count == 0) {
                // Insert sample students
                $sampleStudents = [
                    ['Juan Dela Cruz', 'Computer Science 101', 'Block A'],
                    ['Maria Santos', 'Computer Science 101', 'Block A'],
                    ['Jose Rizal', 'Computer Science 101', 'Block A'],
                    ['Ana Reyes', 'Computer Science 101', 'Block A'],
                    ['Pedro Penduko', 'Computer Science 101', 'Block A'],
                    ['Sofia Garcia', 'Computer Science 101', 'Block B'],
                    ['Carlos Yulo', 'Computer Science 101', 'Block B'],
                    ['Andres Bonifacio', 'Mathematics 201', 'Block A'],
                    ['Gabriela Silang', 'Mathematics 201', 'Block A'],
                    ['Emilio Aguinaldo', 'Physics 301', 'Block C']
                ];
                
                $stmt = $pdo->prepare("INSERT OR IGNORE INTO roster (student_name, subject, section) VALUES (?, ?, ?)");
                foreach ($sampleStudents as $student) {
                    try {
                        $stmt->execute([$student[0], $student[1], $student[2]]);
                    } catch (PDOException $e) {
                        // Skip duplicates
                    }
                }
                echo '<div class="message success">✅ Sample roster data inserted (10 students).</div>';
            } else {
                echo '<div class="message success">✅ Roster already contains ' . $count . ' students.</div>';
            }

            echo '<div class="message success" style="margin-top: 1.5rem; font-size: 1.1rem;">
                <strong>🎉 Database initialization complete!</strong><br>
                All tables created with indexes for optimal performance.
            </div>';
            
            echo '<div style="margin-top: 1.5rem;">';
            echo '<a href="../index.html" class="btn">📊 Admin Dashboard</a>';
            echo '<a href="../scanner.html" class="btn">📱 Student Scanner</a>';
            echo '<a href="../analytics.html" class="btn">📈 Analytics</a>';
            echo '</div>';
            
        } catch (PDOException $e) {
            echo '<div class="message error">❌ Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
            echo '<p style="margin-top: 1rem; color: rgba(255,255,255,0.7);">Troubleshooting:</p>';
            echo '<ul>';
            echo '<li>Make sure XAMPP MySQL service is running</li>';
            echo '<li>Default credentials (root with no password) are correct</li>';
            echo '<li>If using different credentials, update <code>api/db.php</code></li>';
            echo '</ul>';
        }
        ?>
    </div>
</body>
</html>