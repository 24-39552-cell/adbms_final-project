<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$host = 'sql113.infinityfree.com';
$db   = 'if0_41884758_quickattend';
$user = 'if0_41884758';
$pass = 'vZJNQ2TbgrGWjE'; 
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Force Philippine Time for both PHP functions and MySQL database
    date_default_timezone_set('Asia/Manila');
    $pdo->exec("SET time_zone = '+08:00'");
} catch (\PDOException $e) {
    // If database doesn't exist, provide clear error
    if ($e->getCode() == 1049) {
        die(json_encode([
            "success" => false, 
            "error" => "Database not found. Please run init_db.php first.",
            "setup_url" => "api/init_db.php"
        ]));
    }
    die(json_encode(["success" => false, "error" => "Database connection failed: " . $e->getMessage()]));
}
?>