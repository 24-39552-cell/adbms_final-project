<?php
require_once 'db.php';

if (!isset($_GET['session_id'])) {
    die("Session ID is required.");
}
$sessionId = $_GET['session_id'];

// Get session info to name the file correctly
$stmt = $pdo->prepare("SELECT subject, section, professor_name, date(created_at) as session_date FROM sessions WHERE id = ?");
$stmt->execute([$sessionId]);
$session = $stmt->fetch();

if (!$session) {
    die("Session not found.");
}

$filename = "attendance_" . preg_replace('/[^a-zA-Z0-9_]/', '_', $session['subject']) . "_" . $session['section'] . ".csv";

header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=\"$filename\"");

$output = fopen("php://output", "w");
fputcsv($output, ["Student Name", "Subject", "Section", "Professor Name", "Date", "Time", "Status", "Distance (m)"]);

// Fetch attendees
$stmt = $pdo->prepare("SELECT student_name, subject, section, date, timestamp, status, distance FROM attendance WHERE session_id = ? ORDER BY timestamp DESC");
$stmt->execute([$sessionId]);
$attendees = $stmt->fetchAll();

foreach ($attendees as $row) {
    $time = date("h:i:s A", strtotime($row['timestamp']));
    fputcsv($output, [
        $row['student_name'],
        $row['subject'] ?? $session['subject'],
        $row['section'] ?? $session['section'],
        $session['professor_name'],
        $row['date'],
        $time,
        $row['status'] == 'present' ? 'Present' : 'Absent',
        round($row['distance'])
    ]);
}
fclose($output);
?>
