<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';

$action = $_GET['action'] ?? '';

try {
    switch($action) {
        // Get all sessions
        case 'sessions':
            $stmt = $pdo->query("
                SELECT 
                    s.*,
                    COUNT(a.id) as attendance_count
                FROM sessions s
                LEFT JOIN attendance a ON s.id = a.session_id
                GROUP BY s.id
                ORDER BY s.created_at DESC
            ");
            echo json_encode(["success" => true, "data" => $stmt->fetchAll()]);
            break;
            
        // Get attendance report for specific session (using INNER JOIN)
        case 'report':
            if (!isset($_GET['session_id'])) {
                echo json_encode(["success" => false, "error" => "Session ID required"]);
                exit;
            }
            
            $sessionId = $_GET['session_id'];
            
            // INNER JOIN to get comprehensive attendance data with session details
            $stmt = $pdo->prepare("
                SELECT 
                    a.student_name,
                    a.timestamp,
                    a.distance,
                    a.status,
                    a.subject,
                    a.section,
                    a.date,
                    s.professor_name,
                    s.created_at as session_created
                FROM sessions s
                INNER JOIN attendance a ON s.id = a.session_id
                WHERE s.id = ?
                ORDER BY a.timestamp DESC
            ");
            $stmt->execute([$sessionId]);
            $data = $stmt->fetchAll();
            
            // Also get session info using LEFT JOIN for stats
            $stmt2 = $pdo->prepare("
                SELECT 
                    s.*,
                    COUNT(a.id) as total_attendees,
                    ROUND(AVG(a.distance), 2) as avg_distance,
                    SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_count
                FROM sessions s
                LEFT JOIN attendance a ON s.id = a.session_id
                WHERE s.id = ?
                GROUP BY s.id
            ");
            $stmt2->execute([$sessionId]);
            $sessionInfo = $stmt2->fetch();
            
            echo json_encode([
                "success" => true, 
                "data" => $data,
                "session_info" => $sessionInfo
            ]);
            break;
            
        // Dashboard statistics (LEFT JOIN with aggregation)
        case 'dashboard_stats':
            $stmt = $pdo->query("
                SELECT 
                    s.id,
                    s.subject,
                    s.section,
                    s.professor_name,
                    s.status,
                    s.created_at,
                    COUNT(a.id) as total_attendees,
                    ROUND(COALESCE(AVG(a.distance), 0), 2) as avg_distance,
                    SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_count,
                    SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) as absent_count
                FROM sessions s
                LEFT JOIN attendance a ON s.id = a.session_id
                GROUP BY s.id
                ORDER BY s.created_at DESC
                LIMIT 10
            ");
            echo json_encode(["success" => true, "data" => $stmt->fetchAll()]);
            break;
            
        // Complete report with roster comparison (UNION)
        case 'complete_report':
            if (!isset($_GET['session_id'])) {
                echo json_encode(["success" => false, "error" => "Session ID required"]);
                exit;
            }
            
            $sessionId = $_GET['session_id'];
            
            // First get session info
            $stmt = $pdo->prepare("SELECT * FROM sessions WHERE id = ?");
            $stmt->execute([$sessionId]);
            $session = $stmt->fetch();
            
            if (!$session) {
                echo json_encode(["success" => false, "error" => "Session not found"]);
                exit;
            }
            
            // UNION: Combine present students with absent students from roster
            $stmt = $pdo->prepare("
                SELECT 
                    a.student_name,
                    a.status,
                    a.distance,
                    a.timestamp,
                    'Present' as attendance_status
                FROM attendance a
                WHERE a.session_id = ?
                
                UNION ALL
                
                SELECT 
                    r.student_name,
                    'absent' as status,
                    NULL as distance,
                    NULL as timestamp,
                    'Absent' as attendance_status
                FROM roster r
                WHERE r.subject = ? 
                AND r.section = ?
                AND r.student_name NOT IN (
                    SELECT student_name 
                    FROM attendance 
                    WHERE session_id = ?
                )
                
                ORDER BY student_name
            ");
            $stmt->execute([$sessionId, $session['subject'], $session['section'], $sessionId]);
            
            echo json_encode([
                "success" => true, 
                "data" => $stmt->fetchAll(),
                "session_info" => $session
            ]);
            break;
            
        // SUBQUERY: Find sessions with below-average attendance
        case 'low_attendance':
            $stmt = $pdo->query("
                SELECT 
                    s.id,
                    s.subject,
                    s.section,
                    s.professor_name,
                    s.created_at,
                    COUNT(a.id) as attendance_count
                FROM sessions s
                LEFT JOIN attendance a ON s.id = a.session_id
                WHERE s.status = 'completed'
                GROUP BY s.id
                HAVING COUNT(a.id) < (
                    SELECT AVG(attendance_count)
                    FROM (
                        SELECT COUNT(a2.id) as attendance_count
                        FROM sessions s2
                        LEFT JOIN attendance a2 ON s2.id = a2.session_id
                        WHERE s2.status = 'completed'
                        GROUP BY s2.id
                        HAVING COUNT(a2.id) > 0
                    ) as avg_subquery
                )
                ORDER BY attendance_count ASC
            ");
            echo json_encode([
                "success" => true, 
                "data" => $stmt->fetchAll(),
                "message" => "Sessions with below-average attendance"
            ]);
            break;
            
        // Student attendance across all sessions (RIGHT JOIN concept)
        case 'student_history':
            $studentName = $_GET['student_name'] ?? '';
            
            if (empty($studentName)) {
                echo json_encode(["success" => false, "error" => "Student name required"]);
                exit;
            }
            
            $stmt = $pdo->prepare("
                SELECT 
                    a.*,
                    s.professor_name,
                    s.created_at as session_created
                FROM attendance a
                INNER JOIN sessions s ON a.session_id = s.id
                WHERE a.student_name = ?
                ORDER BY a.timestamp DESC
            ");
            $stmt->execute([$studentName]);
            
            echo json_encode([
                "success" => true, 
                "data" => $stmt->fetchAll(),
                "total_sessions" => count($stmt->fetchAll())
            ]);
            
            // Re-execute for the actual data since fetchAll was used
            $stmt->execute([$studentName]);
            echo json_encode([
                "success" => true, 
                "data" => $stmt->fetchAll()
            ]);
            break;
            
        // End a session
        case 'end_session':
            if (!isset($_GET['session_id'])) {
                echo json_encode(["success" => false, "error" => "Session ID required"]);
                exit;
            }
            
            $sessionId = $_GET['session_id'];
            $stmt = $pdo->prepare("UPDATE sessions SET status = 'completed' WHERE id = ?");
            $stmt->execute([$sessionId]);
            
            echo json_encode([
                "success" => true, 
                "message" => "Session ended successfully"
            ]);
            break;
            
        // Get active session
        case 'active_session':
            $stmt = $pdo->query("
                SELECT * FROM sessions 
                WHERE status = 'active' 
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            echo json_encode(["success" => true, "data" => $stmt->fetch()]);
            break;
            
        default:
            echo json_encode(["success" => false, "error" => "Invalid action"]);
    }
} catch (PDOException $e) {
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>