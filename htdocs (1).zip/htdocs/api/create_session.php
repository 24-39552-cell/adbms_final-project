<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Catch the new inputs
    $subject = trim($input['subject'] ?? '');
    $section = trim($input['section'] ?? '');
    $professor = trim($input['professor'] ?? '');
    $lat = isset($input['lat']) ? floatval($input['lat']) : null;
    $lng = isset($input['lng']) ? floatval($input['lng']) : null;
    $radius = isset($input['radius']) ? floatval($input['radius']) : 50;

    // Validate that all required fields are present
    if (empty($subject) || empty($section) || empty($professor) || $lat === null || $lng === null) {
        echo json_encode(["success" => false, "error" => "All fields (Subject, Section, Professor Name, Latitude, Longitude) are required"]);
        exit;
    }

    // Validate coordinates
    if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
        echo json_encode(["success" => false, "error" => "Invalid coordinates. Latitude must be between -90 and 90, longitude between -180 and 180."]);
        exit;
    }

    // Validate radius
    if ($radius < 5 || $radius > 1000) {
        echo json_encode(["success" => false, "error" => "Radius must be between 5 and 1000 meters."]);
        exit;
    }

    // Generate specific unique session ID
    $sessionId = bin2hex(random_bytes(16));
    
    try {
        // Explicitly set the timestamp using PHP's Asia/Manila time
        $currentTimestamp = date('Y-m-d H:i:s');
        
        // Prepare the INSERT statement
        $stmt = $pdo->prepare("INSERT INTO sessions (id, subject, section, professor_name, lat, lng, radius, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?)");
        
        // Execute with the matching variables
        $stmt->execute([$sessionId, $subject, $section, $professor, $lat, $lng, $radius, $currentTimestamp]);
        
        echo json_encode([
            "success" => true, 
            "message" => "Session created successfully", 
            "session_id" => $sessionId,
            "subject" => $subject,
            "section" => $section,
            "professor" => $professor,
            "radius" => $radius,
            "created_at" => $currentTimestamp
        ]);
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "error" => "Database error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "error" => "Invalid request method"]);
}
?>