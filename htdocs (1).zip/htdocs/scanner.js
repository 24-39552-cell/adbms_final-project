const startScanBtn = document.getElementById('startScanBtn');
const resultBox = document.getElementById('resultBox');
let html5QrCode = null;

startScanBtn.addEventListener('click', () => {
    const studentName = document.getElementById('studentName').value.trim();
    if (!studentName) {
        showResult("error", "Please enter your full name before scanning.");
        document.getElementById('studentName').focus();
        return;
    }
    
    if (studentName.length < 2) {
        showResult("error", "Please enter a valid name (at least 2 characters).");
        return;
    }
    
    startScanBtn.style.display = 'none';
    showResult("info", "📷 Requesting camera access...");
    
    if(!html5QrCode) {
        html5QrCode = new Html5Qrcode("reader");
    }
    
    const config = {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1.0
    };
    
    html5QrCode.start(
        { facingMode: "environment" },
        config,
        (decodedText, decodedResult) => {
            console.log('QR Code detected:', decodedText);
            
            html5QrCode.stop().then(() => {
                let sessionId = decodedText.trim();
                
                // Try to parse as JSON first (for backward compatibility)
                try {
                    const parsed = JSON.parse(sessionId);
                    if (parsed.session_id) {
                        sessionId = parsed.session_id;
                        console.log('Extracted session ID from JSON:', sessionId);
                    }
                } catch(e) {
                    // Not JSON, use the raw text directly
                    console.log('Using raw QR text as session ID');
                }
                
                if (!sessionId || sessionId.length < 10) {
                    showResult("error", "Invalid QR code. Please scan the correct classroom QR code.");
                    startScanBtn.style.display = 'block';
                    return;
                }
                
                showResult("info", `✅ QR code detected! Getting your location...`);
                submitAttendance(sessionId, studentName);
                
            }).catch(err => {
                showResult("error", "Failed to stop camera: " + err.message);
                startScanBtn.style.display = 'block';
            });
        },
        (errorMessage) => {
            // Scanning errors are normal
            if (errorMessage && !errorMessage.includes('No MultiFormat Readers')) {
                console.log('Scan attempt:', errorMessage);
            }
        }
    ).catch(err => {
        let errorMsg = "Camera initialization failed. ";
        if (err.message.includes('NotAllowedError') || err.message.includes('Permission')) {
            errorMsg += "Please allow camera permissions in your browser settings.";
        } else {
            errorMsg += err.message;
        }
        showResult("error", errorMsg);
        startScanBtn.style.display = 'block';
        console.error('Camera error:', err);
    });
});

function submitAttendance(sessionId, studentName) {
    if (!navigator.geolocation) {
        showResult("error", "Geolocation is not supported by your browser.");
        startScanBtn.style.display = 'block';
        return;
    }

    showResult("info", "📍 Getting your location...");
    
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            
            console.log('Submitting attendance:', {
                session_id: sessionId,
                student_name: studentName,
                lat: lat,
                lng: lng
            });
            
            fetch('api/submit_attendance.php', {
                method: 'POST',
                body: JSON.stringify({
                    session_id: sessionId,
                    student_name: studentName,
                    lat: lat,
                    lng: lng
                }),
                headers: { 'Content-Type': 'application/json' }
            })
            .then(r => r.json())
            .then(data => {
                console.log('Server response:', data);
                
                if(data.success) {
                    showResult("success", `✅ ${data.message}`);
                    document.getElementById('studentName').value = '';
                } else {
                    showResult("error", `❌ ${data.error}`);
                }
                startScanBtn.style.display = 'block';
                startScanBtn.innerText = "Scan Again";
            })
            .catch(err => {
                showResult("error", "Network error. Please check your connection.");
                console.error('Fetch error:', err);
                startScanBtn.style.display = 'block';
            });
            
        },
        (error) => {
            let errorMsg = "Location error: ";
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMsg += "Location permission denied. Cannot verify physical presence.";
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMsg += "Location information unavailable.";
                    break;
                case error.TIMEOUT:
                    errorMsg += "Location request timed out.";
                    break;
                default:
                    errorMsg += "Unable to verify location.";
            }
            showResult("error", errorMsg);
            startScanBtn.style.display = 'block';
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }
    );
}

function showResult(type, message) {
    resultBox.style.display = 'block';
    resultBox.innerHTML = message;
    
    // Reset styles
    resultBox.style.background = "var(--glass-bg)";
    resultBox.style.color = "#fff";
    resultBox.style.border = "1px solid var(--glass-border)";
    resultBox.style.padding = "15px";
    resultBox.style.borderRadius = "10px";
    
    switch(type) {
        case "error":
            resultBox.style.background = "rgba(255,82,82,0.15)";
            resultBox.style.border = "2px solid var(--error)";
            resultBox.style.borderLeft = "5px solid var(--error)";
            break;
        case "success":
            resultBox.style.background = "rgba(0,230,118,0.15)";
            resultBox.style.border = "2px solid var(--success)";
            resultBox.style.borderLeft = "5px solid var(--success)";
            break;
        case "info":
            resultBox.style.background = "rgba(0,242,254,0.15)";
            resultBox.style.border = "2px solid var(--primary)";
            resultBox.style.borderLeft = "5px solid var(--primary)";
            break;
    }
    
    if (type === "success") {
        setTimeout(() => {
            resultBox.style.display = 'none';
        }, 5000);
    }
}