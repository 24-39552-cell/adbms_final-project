const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Connect to SQLite database
const dbPath = path.resolve(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        
        // Initialize tables
        db.serialize(() => {
            db.run(`CREATE TABLE IF NOT EXISTS Users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                role TEXT NOT NULL DEFAULT 'student'
            )`);

            db.run(`CREATE TABLE IF NOT EXISTS Sessions (
                id TEXT PRIMARY KEY,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                lat REAL,
                lng REAL,
                radius REAL,
                status TEXT DEFAULT 'active'
            )`);

            db.run(`CREATE TABLE IF NOT EXISTS Attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                student_name TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                distance REAL,
                status TEXT DEFAULT 'present',
                FOREIGN KEY (session_id) REFERENCES Sessions(id)
            )`);
            
            // Insert default admin if doesn't exist
            db.run(`INSERT OR IGNORE INTO Users (username, role) VALUES ('admin', 'admin')`);
        });
    }
});

module.exports = db;
