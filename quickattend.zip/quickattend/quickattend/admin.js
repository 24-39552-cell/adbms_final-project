let activeSessionId = null;
let pollInterval = null;

// Populate initial location
document.getElementById('getLocationBtn').addEventListener('click', () => {
    const btn = document.getElementById('getLocationBtn');
    if (!navigator.geolocation) {
        alert('Geolocation is not supported by your browser');
        return;
    }
    
    btn.innerText = "Locating...";
    navigator.geolocation.getCurrentPosition(
        (position) => {
            document.getElementById('lat').value = position.coords.latitude;
            document.getElementById('lng').value = position.coords.longitude;
            btn.innerText = "Get My Location";
        },
        (error) => {
            alert('Unable to retrieve your location. ' + error.message);
            btn.innerText = "Get My Location";
        }
    );
});

// Create Session
document.getElementById('createSessionBtn').addEventListener('click', () => {
    const subject = document.getElementById('subject').value.trim();
    const section = document.getElementById('section').value.trim();
    const professor = document.getElementById('professor').value.trim();
    const lat = document.getElementById('lat').value;
    const lng = document.getElementById('lng').value;
    const radius = document.getElementById('radius').value;
    
    if(!subject || !section || !professor || !lat || !lng || !radius) {
        alert("Please fill out all fields (Subject, Section, Professor Name, Latitude, Longitude, and Allowed Radius).");
        return;
    }
    
    const btn = document.getElementById('createSessionBtn');
    btn.disabled = true;
    btn.innerText = "Generating...";
    
    fetch('api/create_session.php', {
        method: 'POST',
        body: JSON.stringify({ subject, section, professor, lat, lng, radius }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(r => r.json())
    .then(data => {
        btn.disabled = false;
        btn.innerText = "Generate Session QR";
        
        if(data.success) {
            activeSessionId = data.session_id;
            
            // Clear previous QR
            document.getElementById('qrcode').innerHTML = "";
            document.getElementById('qrcode').style.display = "block";
            
            // Generate new QR Code
            new QRCode(document.getElementById("qrcode"), {
                text: activeSessionId,
                width: 250,
                height: 250,
                colorDark : "#2c5364",
                colorLight : "#ffffff",
                correctLevel : QRCode.CorrectLevel.H
            });
            
            // Show the subject and section under the QR code
            document.getElementById('sessionInfo').innerHTML = `
                <strong>${subject}</strong> (${section})<br>
                Professor: ${professor}<br>
                Session ID: ${activeSessionId.substring(0, 8)}...
            `;
            
            // Start Polling Report
            if(pollInterval) clearInterval(pollInterval);
            fetchReport(); // initial fetch
            pollInterval = setInterval(fetchReport, 3000); // format UI every 3 sec
            
            // Enable Download Button
            document.getElementById('downloadReportBtn').disabled = false;
        } else {
            alert("Error: " + data.error);
        }
    })
    .catch(err => {
        btn.disabled = false;
        btn.innerText = "Generate Session QR";
        alert("Network error.");
    });
});

function fetchReport() {
    if(!activeSessionId) return;
    
    fetch('api/get_data.php?action=report&session_id=' + activeSessionId)
    .then(r => r.json())
    .then(res => {
        const tbody = document.querySelector('#reportTable tbody');
        if(res.success) {
            const data = res.data;
            document.getElementById('totalAttended').innerText = data.length;
            if(data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="3" class="text-center">No attendees yet.</td></tr>';
            } else {
                tbody.innerHTML = '';
                data.forEach(row => {
                    const statusClass = row.status === 'present' ? 'badge-success' : 'badge-error';
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${escapeHtml(row.student_name)}</td>
                        <td>${new Date(row.timestamp).toLocaleString([], { year: 'numeric', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                        <td><span class="badge ${statusClass}">${row.status === 'present' ? 'Present' : 'Absent'} (${Math.round(row.distance)}m)</span></td>
                    `;
                    tbody.appendChild(tr);
                });
            }
        }
    })
    .catch(console.error);
}

function escapeHtml(unsafe) {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

document.getElementById('downloadReportBtn').addEventListener('click', () => {
    if(!activeSessionId) return;
    window.location.href = 'api/export_excel.php?session_id=' + activeSessionId;
});