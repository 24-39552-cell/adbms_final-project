const startScanBtn = document.getElementById('startScanBtn');
const resultBox = document.getElementById('resultBox');
let html5QrCode = null;

startScanBtn.addEventListener('click', () => {
    const studentName = document.getElementById('studentName').value.trim();
    if (!studentName) {
        showResult("error", "Please enter your full name before scanning.");
        return;
    }
    
    startScanBtn.style.display = 'none';
    showResult("info", "Requesting camera access...");
    
    if(!html5QrCode) {
        html5QrCode = new Html5Qrcode("reader");
    }
    
    html5QrCode.start(
        { facingMode: "environment" },
        {
            fps: 10,
            qrbox: { width: 250, height: 250 }
        },
        (decodedText, decodedResult) => {
            // QR Code matched
            html5QrCode.stop().then(() => {
                showResult("info", "QR code detected! Securing your location...");
                submitAttendance(decodedText, studentName);
            }).catch(err => {
                showResult("error", "Failed to stop camera.");
            });
        },
        (errorMessage) => {
            // Parse error, ignore
        }
    ).catch(err => {
        showResult("error", "Camera initialization failed. Please allow camera permissions.");
        startScanBtn.style.display = 'block';
    });
});

function submitAttendance(sessionId, studentName) {
    if (!navigator.geolocation) {
        showResult("error", "Geolocation is not supported by your browser.");
        return;
    }

    navigator.geolocation.getCurrentPosition(
        (position) => {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            
            // Post payload
            fetch('api/submit_attendance.php', {
                method: 'POST',
                body: JSON.stringify({
                    session_id: sessionId,
                    student_name: studentName,
                    lat: lat,
                    lng: lng
                }),
                headers: { 'Content-Type': 'application/json' }
            })
            .then(r => r.json())
            .then(data => {
                if(data.success) {
                    showResult("success", `✅ ${data.message}`);
                } else {
                    showResult("error", `❌ ${data.error}`);
                }
                startScanBtn.style.display = 'block';
                startScanBtn.innerText = "Scan Again";
            })
            .catch(err => {
                showResult("error", "Network error while submitting attendance.");
                startScanBtn.style.display = 'block';
            });
            
        },
        (error) => {
            showResult("error", "User denied Geolocation. Cannot verify physical presence.");
            startScanBtn.style.display = 'block';
        },
        {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
        }
    );
}

function showResult(type, message) {
    resultBox.style.display = 'block';
    resultBox.innerHTML = message;
    
    resultBox.style.background = "var(--glass-bg)";
    resultBox.style.color = "#fff";
    
    if(type === "error") {
        resultBox.style.borderLeft = "4px solid var(--error)";
    } else if (type === "success") {
        resultBox.style.borderLeft = "4px solid var(--success)";
    } else {
        resultBox.style.borderLeft = "4px solid var(--primary)";
    }
}
