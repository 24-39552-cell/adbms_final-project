<?php
$host = '127.0.0.1';
$user = 'root';
$pass = '';

try {
    // Connect to MySQL server first without a database
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create Database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS quickattend");
    echo "Database created successfully or already exists.<br>";

    // Connect to specific database
    $pdo->exec("USE quickattend");

    // Create Sessions table
    $query = "CREATE TABLE IF NOT EXISTS sessions (
        id VARCHAR(64) PRIMARY KEY,
        subject VARCHAR(255),
        section VARCHAR(100),
        professor_name VARCHAR(255),
        lat DECIMAL(10, 8),
        lng DECIMAL(11, 8),
        radius FLOAT DEFAULT 50,
        status VARCHAR(20) DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )";
    $pdo->exec($query);
    echo "Sessions table created successfully.<br>";

    // Create Attendance table
    $query = "CREATE TABLE IF NOT EXISTS attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        session_id VARCHAR(64),
        student_name VARCHAR(100) NOT NULL,
        date DATE DEFAULT CURRENT_DATE,
        distance FLOAT,
        status VARCHAR(20) DEFAULT 'present',
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (session_id) REFERENCES sessions(id)
    )";
    $pdo->exec($query);
    echo "Attendance table created successfully.<br>";

    echo "<br><b>Database initialization complete! You can now use the QuickAttend system.</b>";
}
catch (PDOException $e) {
    die("DB ERROR: " . $e->getMessage());
}
?>
