<?php
header('Content-Type: application/json');
require_once 'db.php';

$action = $_GET['action'] ?? '';

try {
    if ($action === 'sessions') {
        $stmt = $pdo->query("SELECT * FROM sessions ORDER BY created_at DESC");
        echo json_encode(["success" => true, "data" => $stmt->fetchAll()]);
    } 
    else if ($action === 'report' && isset($_GET['session_id'])) {
        $sessionId = $_GET['session_id'];
        $stmt = $pdo->prepare("SELECT student_name, timestamp, distance, status FROM attendance WHERE session_id = ? ORDER BY timestamp DESC");
        $stmt->execute([$sessionId]);
        echo json_encode(["success" => true, "data" => $stmt->fetchAll()]);
    }
    else if ($action === 'end_session' && isset($_GET['session_id'])) {
        $sessionId = $_GET['session_id'];
        $stmt = $pdo->prepare("UPDATE sessions SET status = 'completed' WHERE id = ?");
        $stmt->execute([$sessionId]);
        echo json_encode(["success" => true, "message" => "Session ended successfully"]);
    }
    else {
        echo json_encode(["success" => false, "error" => "Invalid action"]);
    }
} catch (PDOException $e) {
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>
