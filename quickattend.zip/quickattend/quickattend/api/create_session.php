<?php
header('Content-Type: application/json');
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Catch the new inputs
    $subject = $input['subject'] ?? '';
    $section = $input['section'] ?? '';
    $professor = $input['professor'] ?? '';
    $lat = isset($input['lat']) ? floatval($input['lat']) : null;
    $lng = isset($input['lng']) ? floatval($input['lng']) : null;
    $radius = isset($input['radius']) ? floatval($input['radius']) : 50;

    // Validate that all required fields are present
    if (!$subject || !$section || !$professor || $lat === null || $lng === null) {
        echo json_encode(["success" => false, "error" => "All fields (Subject, Section, Professor Name, Latitude, Longitude) are required"]);
        exit;
    }

    // Generate specific unique session ID
    $sessionId = bin2hex(random_bytes(16));
    
    try {
        // Explicitly set the timestamp using PHP's Asia/Manila time
        $currentTimestamp = date('Y-m-d H:i:s');
        
        // Prepare the INSERT statement with the new columns
        $stmt = $pdo->prepare("INSERT INTO sessions (id, subject, section, professor_name, lat, lng, radius, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?)");
        
        // Execute with the matching variables
        $stmt->execute([$sessionId, $subject, $section, $professor, $lat, $lng, $radius, $currentTimestamp]);
        
        echo json_encode([
            "success" => true, 
            "message" => "Session created", 
            "session_id" => $sessionId
        ]);
    } catch (PDOException $e) {
        // This will catch errors (e.g., if the table doesn't have the new columns yet)
        echo json_encode(["success" => false, "error" => $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "error" => "Invalid request method"]);
}
?>