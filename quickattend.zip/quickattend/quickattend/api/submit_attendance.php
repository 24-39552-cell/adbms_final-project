<?php
header('Content-Type: application/json');
require_once 'db.php';

function getDistance($lat1, $lon1, $lat2, $lon2) {
    if (($lat1 == $lat2) && ($lon1 == $lon2)) {
        return 0;
    }
    
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    
    $miles = $dist * 60 * 1.1515;
    $meters = $miles * 1609.344; // Convert miles to meters
    return $meters;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $sessionId = $input['session_id'] ?? '';
    $studentName = $input['student_name'] ?? '';
    $lat = isset($input['lat']) ? floatval($input['lat']) : null;
    $lng = isset($input['lng']) ? floatval($input['lng']) : null;

    if (!$sessionId || !$studentName || $lat === null || $lng === null) {
        echo json_encode(["success" => false, "error" => "Missing required parameters"]);
        exit;
    }

    try {
        // Find the active session and grab all its details (including subject and section)
        $stmt = $pdo->prepare("SELECT * FROM sessions WHERE id = ? AND status = 'active'");
        $stmt->execute([$sessionId]);
        $session = $stmt->fetch();

        if (!$session) {
            echo json_encode(["success" => false, "error" => "Invalid or expired session"]);
            exit;
        }

        // Calculate distance
        $distance = getDistance((float)$session['lat'], (float)$session['lng'], $lat, $lng);
        $radius = (float)$session['radius'];

        if ($distance > $radius) {
            echo json_encode([
                "success" => false, 
                "error" => "Geolocation verification failed. You are ". round($distance) ." meters away, but must be within ". round($radius) ." meters of the classroom."
            ]);
            exit;
        }

        // Check if student already submitted attendance
        $stmt = $pdo->prepare("SELECT id FROM attendance WHERE session_id = ? AND student_name = ?");
        $stmt->execute([$sessionId, $studentName]);
        if ($stmt->fetch()) {
            echo json_encode(["success" => false, "error" => "Attendance already recorded for this session"]);
            exit;
        }

        // Extract subject and section from the session data
        $subject = $session['subject'];
        $section = $session['section'];

        // Explicitly set the timestamp using PHP's Asia/Manila time
        $currentDate = date('Y-m-d');
        $currentTimestamp = date('Y-m-d H:i:s');

        // Submit attendance with the new subject and section columns
        $stmt = $pdo->prepare("INSERT INTO attendance (session_id, student_name, subject, section, distance, status, date, timestamp) VALUES (?, ?, ?, ?, ?, 'present', ?, ?)");
        $stmt->execute([$sessionId, $studentName, $subject, $section, $distance, $currentDate, $currentTimestamp]);

        echo json_encode([
            "success" => true,
            "message" => "Attendance recorded successfully for $subject ($section)!"
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "error" => $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "error" => "Invalid method"]);
}
?>