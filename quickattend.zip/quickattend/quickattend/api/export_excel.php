<?php
require_once 'db.php';

if (!isset($_GET['session_id'])) {
    die("Session ID is required.");
}
$sessionId = $_GET['session_id'];

// Get session info
$stmt = $pdo->prepare("SELECT subject, section, professor_name, date(created_at) as session_date FROM sessions WHERE id = ?");
$stmt->execute([$sessionId]);
$session = $stmt->fetch();

if (!$session) {
    die("Session not found.");
}

$filename = "attendance_" . preg_replace('/[^a-zA-Z0-9_]/', '_', $session['subject']) . "_" . $session['section'] . ".xls";

header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

// Output HTML table which Excel can natively parse
echo "<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">";
echo "<head><meta charset=\"utf-8\"></head><body>";
echo "<table border='1'>";
echo "<tr>";
echo "<th>Student Name</th>";
echo "<th>Subject</th>";
echo "<th>Section</th>";
echo "<th>Professor Name</th>";
echo "<th>Date</th>";
echo "<th>Time</th>";
echo "<th>Status</th>";
echo "<th>Distance (m)</th>";
echo "</tr>";

// Fetch attendees
$stmt = $pdo->prepare("SELECT student_name, subject, section, date, timestamp, status, distance FROM attendance WHERE session_id = ? ORDER BY timestamp DESC");
$stmt->execute([$sessionId]);
$attendees = $stmt->fetchAll();

foreach ($attendees as $row) {
    $time = date("h:i A", strtotime($row['timestamp']));
    $subject = htmlspecialchars($row['subject'] ?? $session['subject']);
    $section = htmlspecialchars($row['section'] ?? $session['section']);
    $prof = htmlspecialchars($session['professor_name']);
    $status = $row['status'] == 'present' ? 'Present' : 'Absent';
    $distance = round($row['distance']);
    
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['student_name']) . "</td>";
    echo "<td>" . $subject . "</td>";
    echo "<td>" . $section . "</td>";
    echo "<td>" . $prof . "</td>";
    echo "<td>" . htmlspecialchars($row['date']) . "</td>";
    echo "<td>" . htmlspecialchars($time) . "</td>";
    echo "<td>" . $status . "</td>";
    echo "<td>" . $distance . "</td>";
    echo "</tr>";
}

echo "</table></body></html>";
?>
