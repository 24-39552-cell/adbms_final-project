<?php
$host = '127.0.0.1';
$db   = 'quickattend';
$user = 'root';
$pass = ''; // Default XAMPP password is empty
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Force Philippine Time for both PHP functions and MySQL database
    date_default_timezone_set('Asia/Manila');
    $pdo->exec("SET time_zone = '+08:00'");
} catch (\PDOException $e) {
    // If database doesn't exist, this might fail, so we handle it gracefully in init_db.php
    // In normal operation, a connection failure should terminate.
    die(json_encode(["error" => "Database connection failed: " . $e->getMessage()]));
}
?>
